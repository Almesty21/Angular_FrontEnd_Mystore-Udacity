export interface FormDataType {
    name: string;
}