export interface ProductType {
    id: number;
    url: string;
    name: string;
    price: number;
    description: string;
    quantity: string;
}